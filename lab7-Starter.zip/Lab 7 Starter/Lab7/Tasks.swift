//
//  Tasks.swift
//  Lab7
//
//  Created by Gaurav Shah on 4/7/21.
//

import SwiftUI

//Our Simple Task Model

struct Tasks: Identifiable {
    var id = UUID()
    var title: //TODO: FILL IN WHAT TYPE TITLE SHOULD BE
    var completed: //TODO: FILL IN WHAT TYPE COMPLETED SHOULD BE
    var deadline: String
}
