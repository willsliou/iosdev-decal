//
//  ViewController.swift
//  Hangman-Starter
//
//  Created by Shyam Kumar on 2/25/21.
//

import UIKit

//MARK:- Helpful Methods

    // Changing the image of a UIImageView - imageView.image = UIImage(named:"hangman2")  https://developer.apple.com/documentation/uikit/uiimageview

    // Creating and presenting a UIAlertViewController -  https://developer.apple.com/documentation/uikit/uialertcontroller
        // let alert = UIAlertController(title: "My Alert", message: "This is an alert.", preferredStyle: .alert)
        // self.present(alert, animated: true, completion: nil)

class ViewController: UIViewController {
    
    var hangman = Hangman()
    
    //MARK:- @IBOUTLETS
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
        
    }
    
    //MARK:- HELPER METHODS
    
    
    
    
    
    //MARK:- ACTION METHODS
    
    
    
}

