//
//  lab09App.swift
//  lab09
//
//  Created by Shyam Kumar on 11/8/20.
//

import SwiftUI

@main
struct lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(rq: RequestData())
        }
    }
}
